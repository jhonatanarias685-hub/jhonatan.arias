# Portafolio profesional — Jhonatan Arias Cerquera

Sitio estático en HTML, CSS y JavaScript listo para GitHub Pages.

## Publicación rápida

1. Crea un repositorio en GitHub, idealmente `jhonatanarias.github.io`.
2. Sube `index.html`, `styles.css`, `script.js` y el PDF de tu CV.
3. Si el repositorio tiene otro nombre, ve a `Settings > Pages`.
4. Selecciona `Deploy from a branch`, rama `main`, carpeta `/ (root)`.
5. Guarda y espera a que GitHub publique la URL.

El botón "Descargar CV" espera encontrar en la raíz el archivo:
`CV_Jhonatan_Arias_Starbucks_Sostenibilidad.pdf`
